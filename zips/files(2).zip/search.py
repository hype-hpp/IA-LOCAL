"""
Fase 02 - 2.5d: Busca manual para validar hybrid search com dados reais.

Uso:
    python scripts/search.py "sua pergunta aqui"
"""

import os
import sys
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src", "retrieval"))
from hybrid_search import hybrid_search


def main():
    parser = argparse.ArgumentParser(description="Busca híbrida (dense + BM25) no global_scope")
    parser.add_argument("query", help="Texto da busca")
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    print(f"Buscando: '{args.query}'\n")
    results = hybrid_search(args.query, top_k=args.top_k)

    if not results:
        print("Nenhum resultado. O global_scope está vazio? Rode scripts/ingest_document.py primeiro.")
        return

    for i, r in enumerate(results, 1):
        preview = (r["text"] or "")[:200].replace("\n", " ")
        print(f"{i}. [score={r['score']}] fonte={r['source']}")
        print(f"   {preview}...\n")


if __name__ == "__main__":
    main()
