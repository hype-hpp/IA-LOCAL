# Fase 02 — Passo 2.1 + 2.2 (Fundação de armazenamento + Qdrant)

## O que este passo faz
1. Cria a separação física `./chats/{chat_id}/` (temporário) vs `./knowledge/` (persistente), conforme Decision 018.
2. Sobe o Qdrant via Docker.
3. Cria duas collections isoladas: `chat_scope` e `global_scope`, com índices de payload em `chat_id`, `source` e `content_hash`.

## Como rodar (Arch Linux)

```bash
# 1. Extrair estes arquivos para dentro do seu diretório do projeto (ex: ~/crawler-ai/ia-local)
cd ~/crawler-ai/ia-local   # ajuste para o seu path real

# 2. Criar a estrutura de diretórios
chmod +x setup_dirs.sh
./setup_dirs.sh

# 3. Subir o Qdrant
docker compose up -d

# 4. Verificar se subiu
docker compose ps
curl http://localhost:6333/healthz

# 5. Instalar dependência Python (dentro do venv ~/crawler-ai)
source ~/crawler-ai/bin/activate   # ajuste se o venv tiver outro nome/path
pip install -r requirements.txt

# 6. Criar as collections
python create_collections.py
```

## Checklist de validação (regra 18 — testar no hardware real)

- [ ] `docker compose ps` mostra `ia_local_qdrant` como `running`/`healthy`
- [ ] `curl http://localhost:6333/healthz` retorna OK
- [ ] `python create_collections.py` roda sem erro e imprime as duas collections criadas
- [ ] Dashboard do Qdrant acessível em `http://localhost:6333/dashboard` mostrando `chat_scope` e `global_scope`
- [ ] `./chats/` e `./knowledge/documents/` e `./knowledge/cache/` existem

## Decisão pendente de confirmação

`VECTOR_SIZE=2560` em `create_collections.py` assume a dimensão de embedding do **Qwen3-Embedding-4B**. Isso só pode ser confirmado quando rodarmos o modelo real (passo 2.3) e checarmos o tamanho do vetor retornado. Se a dimensão for diferente, as collections precisam ser recriadas — sem problema nesta fase porque ainda não há dados indexados.

## Próximo passo (2.3)

Depois de validar o checklist acima, seguimos para o pipeline de embedding com Qwen3-Embedding-4B via Ollama, e aí confirmamos o `VECTOR_SIZE` de verdade.
